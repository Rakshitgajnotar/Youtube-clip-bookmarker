# YTClip-Bookmarker
This Chrome extension detects when a YouTube video is being watched, extracts the video ID, and sends it for further processing. It listens for tab updates, identifies YouTube video pages, and communicates with a content script. Perfect for video bookmarking, tracking history, or video-based actions.
